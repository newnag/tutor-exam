<?php get_header(); ?>

<main>
    <article>
        <div class="content container">
            <p>Test</p>
        </div>
    </article>
</main>

</body>
</html>